package com.api.gateway;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FallBackController {

	@GetMapping("/bookServiceFallBack")
	public String bookServiceFallBackMethod() {
		return " Book service is not available, plese try later";
	}
	
	@GetMapping("/subscriptionServiceFallBack")
	public String subscriptionServiceFallBackMethod() {
		return "Subscription Service is not available, please try later";
	}
}
